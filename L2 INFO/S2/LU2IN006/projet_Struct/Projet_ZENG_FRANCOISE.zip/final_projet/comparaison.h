#ifndef COMPARAISONS_H
#define COMPARAISONS_H
#include "Chaine.h"
#include "Reseau.h"
#include "Hachage.h"
#include "ArbreQuat.h"

//double generateRandomDouble(int maximum);
Chaines* generationAleatoire(int nbChaines, int nbPointsChaine, int xmax, int ymax);
#endif