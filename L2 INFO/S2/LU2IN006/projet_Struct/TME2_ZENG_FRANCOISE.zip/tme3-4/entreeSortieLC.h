#ifndef ENTRE_SORTIE_H
#define ENTRE_SORTIE_H
#include "biblioLC.h"
Biblio* charger_n_entrees(char* nomfic, int n);
void enregistrer_biblio(Biblio *b, char* nomfic);


#endif