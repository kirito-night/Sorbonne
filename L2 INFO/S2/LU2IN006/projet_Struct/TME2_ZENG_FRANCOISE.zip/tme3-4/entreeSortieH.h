#ifndef E_SORTIE_H
#define E_SORTIE_H
#include "biblioH.h"
BiblioH* charger_n_entrees_h(char* nomfic, int n);

void enregistrer_biblio_h(BiblioH *b, char* nomfic);
#endif