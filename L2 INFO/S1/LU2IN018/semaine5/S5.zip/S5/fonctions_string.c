#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "devel.h"

void *dupliquer_str(const void *src) {
  /* a completer. Exercice 5, question 1 */
  char **isrc  = (char **)src;
  char *idest = strdup(*isrc);
  if (idest==NULL) {
    affiche_message("Erreur d'allocation");
    return NULL;
  }
  *idest = **isrc;


  return  (void *) idest; // pour que cela compile
}




void copier_str(const void *src, void *dst) {
  char ** isrc = (char**) src;
  char ** idst = (char**) dst;
  char * tmp = strdup(*isrc);
   if (tmp==NULL) {
    affiche_message("Erreur d'allocation");
    return;
  }
  *idst = tmp;
}
void detruire_str(void *data) {
  /* a completer. Exercice 5, question 1 */
  free(data);
}

void afficher_str(const void *data) {
  /* a completer. Exercice 5, question 1 */
  char * s = (char *)data;
  printf("%s \n", s);
}

int comparer_str(const void *a, const void *b) {
  /* a completer. Exercice 5, question 1 */
  char *ia=(char *)a;
  char *ib=(char*)b;
  
  return strcmp(ia,ib);; // pour que cela compile
}

int ecrire_str(const void *data, FILE *f) {
  /* a completer. Exercice 5, question 1 */
  char ** s = (char **)data; 
  
  return fprintf(f, " %s \n", *s); // pour que cela compile
}

void * lire_str(FILE *f) {
  
  char *s = malloc(sizeof(char)* 200); 
  if(s == NULL){
    printf("erreur allocation");
    return NULL;
  }
  int r = fscanf(f, "%s\n", s);
  if(r<1){
    printf("erreur de lecture");
    return NULL;
  }
  char* res = strdup(s);
  free(s);
  afficher_str((void *) res);

  return (void *) res; // pour que cela compile
}

