public class TabPleinExeption extends Exception{
    /**
     *
     */
    private static final long serialVersionUID = 4409761629365268207L;

    public TabPleinExeption(String s) {
        super(s);
    }

    @Override
    public String toString() {
        return "TabPleinExeption [] le tableau est plein";
    }
    
    
}
