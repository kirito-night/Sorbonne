public  class MonTableau{
    protected int [] tab;
    protected int lgReelle = 0;

    public MonTableau(int taille) {
        tab = new int[taille];

    }

    public void  ajouter(int n) throws TabPleinExeption{
        lgReelle++;
        if(lgReelle >= tab.length){
             throw new TabPleinExeption("depassement de la borne a la position : " +lgReelle +" ");
         }
        tab[lgReelle - 1] = n; 
        
    }
}
    
