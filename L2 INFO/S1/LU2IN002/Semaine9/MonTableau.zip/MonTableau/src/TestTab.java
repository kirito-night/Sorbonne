
public class TestTab {
    public static void main(String[] args) {
        MonTableau tab = new MonTableau(3);
        try{
            for(int i = 0 ; i < 10; i++){
                tab.ajouter(10);
            }
            
        }
        catch( TabPleinExeption e){
            System.out.println( e.getMessage() + e.toString());
        }

    }



}
