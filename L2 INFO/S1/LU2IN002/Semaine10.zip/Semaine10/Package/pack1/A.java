package pack1;
/* cette class est dans le pack 1*/

public class A {
    public String cat(String s1 , String s2) {
        return s1 +s2;
        
    }

    @Override
    public String toString() {
        return "A []";
    }


}