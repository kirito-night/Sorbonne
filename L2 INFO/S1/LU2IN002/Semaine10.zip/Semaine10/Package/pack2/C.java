package pack2;
/* cette class est dans le pack 2*/
public class C {
    
    public int sum(int i , int j) {
        return i+j;
        
    }
    @Override
    public String toString() {
        return "C [] : ";
    }

    public C() {
    }
    
}
