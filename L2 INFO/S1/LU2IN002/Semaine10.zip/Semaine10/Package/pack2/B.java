package pack2;
/* cette class est dans le pack 2*/

public class B {


    public void show(String s) {
        System.out.println(s);
        
    }
    @Override
    public String toString() {
        return "B []";
    }
    
}
