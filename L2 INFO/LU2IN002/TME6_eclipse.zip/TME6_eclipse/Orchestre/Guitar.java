public class Guitar extends Instrument{
	public Guitar(double poids, double prix){
		super(poids, prix);
	}
	public void jouer(){
		System.out.println(" La guitar joue");
	}
}
