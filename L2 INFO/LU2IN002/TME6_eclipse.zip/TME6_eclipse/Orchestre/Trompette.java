public class Trompette extends Instrument{
	public Trompette(double poids, double prix){
		super(poids, prix);
	}
	public void jouer(){
		System.out.println(" La trompette joue");
	}
}
