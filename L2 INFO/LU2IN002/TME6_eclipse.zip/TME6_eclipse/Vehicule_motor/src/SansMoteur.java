
public class SansMoteur extends Vehicule {
	public SansMoteur() {
			super();
	}

	@Override
	public String toString() {
		return super.toString() + ":: SansMoteur []";
	}
	
	public void transporter (String depart, String arrivee) {}
	
}
