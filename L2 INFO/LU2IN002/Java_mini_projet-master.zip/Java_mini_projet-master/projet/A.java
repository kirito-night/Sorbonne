package projet;

public class A {
    public static int i = 3;
    public int a;
    protected int b;

    public A(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    
}
