

public class TestEtudiant {
    public static void main(String[] args) {
        Etudiant etu = null;
        int i;
        for(i = 0 ; i < args.length ; i++){
                try{
                    int note = Integer.parseInt(args[i]);
                    //System.out.println(args[i] +" est une note");
                    if(etu != null){
                        etu.entrerNote(note);
                    }
                }
                catch (NumberFormatException e) {
             
                    //System.out.println(e + "est un nom");
                    if(etu != null){
                        System.out.println(etu);
                    }
                    etu = new Etudiant(args[i]);
                    
                }
                catch(TabNotesPleinException e){
                    System.out.println("le tableau de " + etu.nom + " est plein\n");
                }
        }

        System.out.println("finished");
    }
}
