

public class TabNotesPleinException extends Exception {
    /**
     *
     */
    private static final long serialVersionUID = 7860563353439659186L;

    public TabNotesPleinException(String s) {
        super(s);
    }

    @Override
    public String toString() {
        return "TabNotesPleinException : les notes sont remplits";
    }
    
    
}
