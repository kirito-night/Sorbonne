import java.util.ArrayList;
import java.util.Arrays;

public class Etudiant {
    protected String nom;
    protected int[] notes = new int[5];
    protected int lgReelle = 0;
    protected static ArrayList<Etudiant> etudiants = new ArrayList<Etudiant>();

    public Etudiant(String nom) {
        
        this.nom = nom;
    }

   


    @Override
    public String toString() {
        String allNotes = "";
        for (int i = 0; i < lgReelle; i++) {
            allNotes += notes[i] + " ";
        }
        return "nom :" + nom + ", note : " + allNotes + "\n";
    }

    public void entrerNote(int note) throws TabNotesPleinException {
        lgReelle+=1;

        if(lgReelle >= notes.length){
            throw new TabNotesPleinException("le tableau de note : " + nom +" est plein \n"); 
        }
        notes[lgReelle-1] = note;
    }

    




    

    
}