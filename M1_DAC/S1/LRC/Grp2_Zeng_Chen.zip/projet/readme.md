# Projet LRC 
Ecriture en Prolog d’un démonstrateur basé sur l’algorithmedes tableaux pour la logique de description ALC.
- Fanxiang ZENG 28600693
- Lucie Chen 28610408
  
Master informatique - Sorbonne Université 2022-2023, M1 S1

# Execution du Programme
- lancer Prolog (avec `swipl`  de preference) dans le repertoire du projet
- entrez `[main].` ou `['main.pl'].` 
- apres l'affichage  d'un   `true` entrez `programme.` pour lancer le projet
- Entrez le numero du type de proposition que vous voulez demontrer comme indiquez sur le terminal
  - pour 1 : 
    - entrez le nom de l'instance que vous voulez démontrer
    - puis entrez  le nom du concept que vous voulez demontrer 
  - pour 2: 
    - entrez les deux concepts dont vous voulez demontrer 

  
