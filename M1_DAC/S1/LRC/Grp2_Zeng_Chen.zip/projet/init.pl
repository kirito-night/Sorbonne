%T-box
equiv(sculpteur,and(personne,some(aCree,sculpture))).
equiv(auteur,and(personne,some(aEcrit,livre))).
equiv(editeur,and(personne,and(not(some(aEcrit,livre)),some(aEdite,livre)))).
equiv(parent,and(personne,some(aEnfant,anything))).

%concept atomique 
cnamea(personne).
cnamea(livre).
cnamea(objet).
cnamea(sculpture).
cnamea(anything).
cnamea(nothing).
%concept non atomique 
cnamena(auteur).
cnamena(editeur).
cnamena(sculpteur).
cnamena(parent).

% nom instance 
iname(michelAnge).
iname(david).
iname(sonnets).
iname(vinci).
iname(joconde).
% nom role 
rname(aCree).
rname(aEcrit).
rname(aEdite).
rname(aEnfant).

%Abox
%instanciation des concepts 
inst(michelAnge,personne).
inst(david,sculpture).
inst(sonnets,livre).
inst(vinci,personne).
inst(joconde,objet).

%instanciation des roles
instR(michelAnge,david,aCree).
instR(michelAnge,sonnets,aEcrit).
instR(vinci,joconde,aCree).

