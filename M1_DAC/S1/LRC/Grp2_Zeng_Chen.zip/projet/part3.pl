%include
:-[init].
:-[utils].
:-[part1].
:-[part2].

troisieme_etape(Abi,Abr) :-
    tri_Abox(Abi,Lie,Lpt,Li,Lu,Ls),
    resolution(Lie,Lpt,Li,Lu,Ls,Abr),
    nl,write('Youpiiiiii, on a demontre la
    proposition initiale !!!').


% - la liste Lie (liste il existe) des assertions du type (I,some(R,C))
% - la liste Lpt (liste pour tout) des assertions du type (I,all(R,C))
% - la liste Li (liste intersection) des assertions du type (I,and(C1,C2))
% - la liste Lu (liste union) des assertions du type (I,or(C1,C2))
% - la liste Ls des assertions restantes, à savoir les assertions du type (I,C) ou (I,not(C)), C étant un concept atomique.

/*tri est réalisé avant le processus de résolution pour accélérer la recherche d’une assertion
 susceptible de provoquer l’application de l‘une des 4 règles permettant de développer l’arbre de démonstration.*/
tri_Abox([],[],[],[],[],[]).

/*  parcours de tous les elements du type I : some(R,C) */
tri_Abox([(I,some(R,C))|Abi],[(I,some(R,C))|Lie],Lpt,Li,Lu,Ls) :- tri_Abox(Abi,Lie,Lpt,Li,Lu,Ls).

/*  parcours de tous les elements du type I : all(R,C) */
tri_Abox([(I,all(R,C))|Abi],Lie,[(I,all(R,C))|Lpt],Li,Lu,Ls) :- tri_Abox(Abi,Lie,Lpt,Li,Lu,Ls).

/*  parcours de  tous les elements du type I : and(C1,C2) */
tri_Abox([(I,and(C1,C2))|Abi],Lie,Lpt,[(I,and(C1,C2))|Li],Lu,Ls) :- tri_Abox(Abi,Lie,Lpt,Li,Lu,Ls).

/*  parcours  de tous les elements du type I : or(C1,C2) */
tri_Abox([(I,or(C1,C2))|Abi],Lie,Lpt,Li,[(I,or(C1,C2))|Lu],Ls) :- tri_Abox(Abi,Lie,Lpt,Li,Lu,Ls).

/*  parcours  de tous les elements du type (I : C) ou (I : not(C)) */
tri_Abox([(I,C)|Abi],Lie,Lpt,Li,Lu,[(I,C)|Ls]) :- cnamea(C),tri_Abox(Abi,Lie,Lpt,Li,Lu,Ls).
tri_Abox([(I,not(C))|Abi],Lie,Lpt,Li,Lu,[(I,not(C))|Ls]) :- cnamea(C),tri_Abox(Abi,Lie,Lpt,Li,Lu,Ls).

% une nouvelle assertion de concepts à intégrer dans l’une des listes Lie, Lpt, Li, Lu ou Ls qui décrivent
% les assertions de concepts de la Abox étendue et Lie1, Lpt1, Li1,Lu1 et Ls1 représentent les nouvelles listes mises à jour.
evolue((I,some(R,C)), Lie, Lpt, Li, Lu, Ls, [(I,some(R,C))|Lie], Lpt, Li, Lu, Ls).
evolue((I,all(R,C)), Lie, Lpt, Li, Lu, Ls, Lie, [(I,all(R,C))|Lpt], Li, Lu, Ls).
evolue((I,and(R,C)), Lie, Lpt, Li, Lu, Ls, Lie, Lpt, [(I,and(R,C))|Li], Lu, Ls).
evolue((I,or(R,C)), Lie, Lpt, Li, Lu, Ls, Lie, Lpt, Li, [(I,or(R,C))|Lu], Ls).
evolue((I,C), Lie, Lpt, Li, Lu, Ls, Lie, Lpt, Li, Lu, [(I,C)|Ls]).
evolue((I,not(C)), Lie, Lpt, Li, Lu, Ls, Lie, Lpt, Li, Lu, [(I,not(C))|Ls]).

% applique evolue sur tout les éléments de la liste d’assertions de concepts
evolue_all([(I,some(R,C))|Tmp],Lie,Lpt,Li,Lu,Ls,Lie1,Lpt,Li,Lu,Ls) :- concatene([(I,some(R,C))|Tmp],Lie,Lie1).
evolue_all([(I,all(R,C))|Tmp],Lie,Lpt,Li,Lu,Ls,Lie,Lpt1,Li,Lu,Ls) :- concatene([(I,all(R,C))|Tmp],Lpt,Lpt1).
evolue_all([(I,and(R,C))|Tmp],Lie,Lpt,Li,Lu,Ls,Lie,Lpt,Li1,Lu,Ls) :- concatene([(I,and(R,C))|Tmp],Li,Li1).
evolue_all([(I,or(R,C))|Tmp],Lie,Lpt,Li,Lu1,Ls,Lie,Lpt,Li,Lu,Ls) :- concatene([(I,or(R,C))|Tmp],Lu,Lu1).
evolue_all([(I,C)|Tmp],Lie,Lpt,Li,Lu,Ls,Lie,Lpt,Li,Lu,Ls1) :- concatene([(I,C)|Tmp],Ls,Ls1).


/* test si y'a un clash */
clash_test([(A,B)|L]):- nnf(not(B),E), member((A,E),L), write("\t clash ! \n\n").
clash_test([_|L]):- clash_test(L). 

/* faire la resolution en utilisant avec les predicats resolution, complete_some, transformation_and, deduction_all, transformation_or */
resolution([],[],[],[],Ls,_) :- clash_test(Ls),!.
resolution(Lie,Lpt,Li,Lu,Ls,Abr) :- 
    (clash_test(Ls); % test de si y'a y'a un clash  en premier 
    complete_some(Lie,Lpt,Li,Lu,Ls,Abr);
    transformation_and(Lie, Lpt,Li,Lu,Ls,Abr);
    deduction_all(Lie,Lpt,Li,Lu,Ls,Abr);
    transformation_or(Lie,Lpt,Li,Lu,Ls,Abr)),!.




% Ce predicat cherche une assertion de concept de la forme (I,some(R,C)) dans la liste Lie.
%  S’il en trouve une, il cherche à appliquer la règle ∃
complete_some([(A,some(R,C)) | Lie],Lpt,Li,Lu,Ls,Abr) :- 
    genere(B),
    evolue((B,C),Lie,Lpt,Li,Lu,Ls,Lie1,Lpt1,Li1,Lu1,Ls1),
    write("\n on utilise la regle ∃ :\n"),
    affiche_evolution_Abox(Lie,Lpt,Li,Lu,Ls,Abr,Lie1,Lpt1,Li1,Lu1,Ls1,[(A,B,R)|Abr]),nl,
    !,resolution(Lie1,Lpt1,Li1,Lu1,Ls1,[(A,B,R)|Abr]),!.

% Ce prédicat cherche une assertion de concept de la forme (I,and(C1,C2)) dans la liste Li.
%  S’il en trouve une, il cherche à appliquer la règle ⊓
transformation_and(Lie,Lpt,[(A,and(C,D))|Li],Lu,Ls,Abr) :- 
    evolue((A,C),Lie,Lpt,Li,Lu,Ls,Lie1,Lpt1,Li1,Lu1,Ls1),
    evolue((A,D),Lie1,Lpt1,Li1,Lu1,Ls1,Lie2,Lpt2,Li2,Lu2,Ls2),
    write("\n on utilise la regle ⊓ :\n"),
    affiche_evolution_Abox(Lie,Lpt,Li,Lu,Ls,Abr,Lie2,Lpt2,Li2,Lu2,Ls2,Abr),nl,!,resolution(Lie2,Lpt2,Li2,Lu2,Ls2,Abr),!.

% Ce prédicat cherche une assertion de concept de la forme (I,all(R,C)) dans la liste Lpt. 
% S’il en trouve une, il cherche à appliquer la règle ∀
deduction_all(Lie,[(A,all(R,C))|Lpt],Li,Lu,Ls,Abr) :- 
    setof((Y,C),
    member((A,Y,R),Abr),Tmp),
    evolue_all(Tmp,Lie,Lpt,Li,Lu,Ls,Lie1,Lpt1,Li1,Lu1,Ls1),
    write("\n on utilise la regle ∀ :\n"),
    affiche_evolution_Abox(Lie,Lpt,Li,Lu,Ls,Abr,Lie1,Lpt1,Li1,Lu1,Ls1,Abr),nl,!,resolution(Lie1,Lpt1,Li1,Lu1,Ls1,Abr),!.

% Ce prédicat cherche une assertion de concept de la forme (I,or(C1,C2)) dans la liste Lu.
%  S’il en trouve une, il cherche à appliquer la règle ⊔
transformation_or(Lie,Lpt,Li,[(A,or(C,D))|Lu],Ls,Abr) :- 
    write("\n on utilise la regle ⊔ :\n"),
    evolue((A,C),Lie,Lpt,Li,Lu,Ls,Lie1,Lpt1,Li1,Lu1,Ls1),
    evolue((A,D),Lie,Lpt,Li,Lu,Ls,Lie2,Lpt2,Li2,Lu2,Ls2),
    write("\n branche 1:\n"),
    affiche_evolution_Abox(Lie,Lpt,Li,Lu,Ls,Abr,Lie1,Lpt1,Li1,Lu1,Ls1,Abr),nl,
    write("\n branche 2:\n"),
    affiche_evolution_Abox(Lie,Lpt,Li,Lu,Ls,Abr,Lie2,Lpt2,Li2,Lu2,Ls2,Abr),nl,!,
    resolution(Lie1,Lpt1,Li1,Lu1,Ls1,Abr),!,resolution(Lie2,Lpt2,Li2,Lu2,Ls2,Abr),!.


/* Affiche evolution Abox */
affiche_evolution_Abox(Ls1, Lie1, Lpt1, Li1, Lu1, Abr1, Ls2, Lie2, Lpt2, Li2, Lu2, Abr2):-
	write("---------------------------------"),
	affiche_etat([Ls1, Lie1, Lpt1, Li1, Lu1, Abr1]),
	write("---------------------------------"),nl,
	write("|\n"),
	write("|\n"),
	write("---------------------------------"),
	affiche_etat([ Ls2, Lie2,Lpt2, Li2, Lu2, Abr2]),
	write("---------------------------------"),
	nl,nl,!.


/* Affichage de l'état de la Abox étendue*/
affiche_etat([]):- nl.
affiche_etat([L1 | L]):-
	afficheAbox_all(L1), affiche_etat(L).

/* Affichage d'une liste d'assertion*/
afficheAbox_all([]).
afficheAbox_all([(A,C)|L]):- nl,
	(cnamena(A) ,writef('| %w ≡ ', [A]));
	(writef('| %w : ', [A])),
	afficheAbox(C),
	afficheAbox_all(L).

afficheAbox_all([(A,B,R)|L]):- nl,
	writef('| <%w , %w> : %w', [A,B,R]),
	afficheAbox_all(L).

/* Affichage  d'une assertion */
afficheAbox(and(C1,C2)):-
	afficheAbox(C1),
	write(" ⊓ "),
	afficheAbox(C2).

afficheAbox(or(C1,C2)):-
	afficheAbox(C1),
	write(" ⊔ "),
	afficheAbox(C2).

afficheAbox(all(R,C)):-
	writef('∀%w.',[R]),afficheAbox(C).

afficheAbox(some(R,C)):-
	writef('∃%w.',[R]), afficheAbox(C).

afficheAbox(not(C)):-
	write('¬ '), afficheAbox(C).

afficheAbox(C):- write(C).
	