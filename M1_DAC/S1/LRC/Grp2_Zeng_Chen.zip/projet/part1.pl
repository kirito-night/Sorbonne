:-[init].
:-[utils].
/* ---------------------- Partie 1 ---------------------- */

%autoreference check pour Tbox non circulaire 
error_autoref(A,B) :- writeln("Error : autoreference check failed for "),writeln((A,B)). 
autoref([(C,E)|Tbox]):- autoref(C,E), error_autoref(C,E);autoref(Tbox).
autoref(X,X,_). 
autoref(_,Y,L):- member(Y,L). 
autoref(X,Y,L):- equiv(Y,Z), autoref(X,Z,[Y|L]).
autoref(X,and(Y,Z),L):- autoref(X,Y,L); autoref(X,Z,L).
autoref(X,or(Y,Z),L):- autoref(X,Y,L); autoref(X,Z,L).
autoref(X,some(_,Z),L):- autoref(X,Z,L).
autoref(X,all(_,Z),L):- autoref(X,Z,L).
autoref(X,not(Y),L):- autoref(X,Y,L).
autoref(X,Y):- autoref(X,Y, []).
%pas_autoref revient a faire un not(autoref)


/* Verification syntaxique et semantique */
concept(I1, I2, R):- iname(I1), iname(I2), rname(R).
concept(C, E):- (cnamena(C); iname(C)), concept(E).
concept(not(C)) :- concept(C),!.
concept(and(C1,C2)) :- concept(C1),concept(C2),!.
concept(or(C1,C2)) :- concept(C1),concept(C2),!.
concept(some(R,C)) :- rname(R),concept(C),!.
concept(all(R,C)) :- rname(R),concept(C),!.
concept(C) :- setof(X,cnamea(X),L),member(C,L),!.
concept(C) :- equiv(C,C2), concept(C2),cnamena(C).
concept(anything).
concept(nothing).


concept_all([], [], []).
concept_all(TBox, ABox1, [(A,B,C)|ABox2]):- concept(A,B,C), concept_all(TBox, ABox1, ABox2),!.
concept_all(TBox,[(A,B)|ABox1], ABox2):- concept(A,B), concept_all(TBox, ABox1, ABox2),!.
concept_all([(A,B)|TBox],ABox1, ABox2):- concept(A,B), concept_all(TBox, ABox1, ABox2),!.


/*TBox :
[(sculpteur,and(personne,some(aCree,sculpture))), (auteur,and(personne,some(aEcrit,livre))), (editeur,and(personne,and(not(some(aEcrit,livre)),some(aEdite,livre)))), (parent,and(personne,some(aEnfant,anything)))]
*/
/*ABox :
  - assertions de concepts :
[(michelAnge,personne), (david,sculpture), (sonnets,livre), (vinci,personne), (joconde,objet)]
  - assertions de rôles :
  [(michelAnge, david, aCree), (michelAnge, sonnet, aEcrit),(vinci, joconde, aCree)]
*/

/* avant de faire les traitement on doit remplacer les  concepts complexe, pour qu'il contient que des concepts atomique */
remplace_complexe(X,X) :-cnamea(X).
remplace_complexe(not(X),not(Y)) :- remplace_complexe(X,Y).
remplace_complexe(and(X,Y),and(Z,W)) :- remplace_complexe(X,Z),remplace_complexe(Y,W).
remplace_complexe(or(X,Y),or(Z,W)) :- remplace_complexe(X,Z),remplace_complexe(Y,W).
remplace_complexe(some(R,X),some(R,Y)) :- remplace_complexe(X,Y).
remplace_complexe(all(R,X),all(R,Y)) :- remplace_complexe(X,Y).
remplace_complexe(X,Y) :- equiv(X,Z), remplace_complexe(Z,Y).

%traitement de TBox
traitement_Tbox([],[]).
traitement_Tbox([(C1,C2)|Tbox],[(C1,C4)|Tbox2]) :- remplace_complexe(C2,C3),nnf(C3,C4) ,traitement_Tbox(Tbox,Tbox2). %remplacement des concepts complexes par des concepts atomiques et mettre sous forme nnf



%traitement de ABox
traitement_Abox([],[]).
traitement_Abox([(A,B)|Abox], [(A,D)|L]):- remplace_complexe(B,C),nnf(C,D),traitement_Tbox(Abox, L).

