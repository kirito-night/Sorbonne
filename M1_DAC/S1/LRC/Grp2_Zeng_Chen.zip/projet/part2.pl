%include
:-[init].
:-[utils].
:-[part1].
/* ---------------------- Partie 2 ---------------------- */
/* Recuperation de la Tbox*/
tbox(L) :- setof((X,Y),equiv(X,Y),L).

/* Recuperation de la Abox*/
/*  ABI = liste de ( instance, concept) */
abi(L) :- setof((X,Y),inst(X,Y),L).

/*  ABR = liste de ( instance,instance, role) */
abr(L) :- setof((X,Y,Z),instR(X,Y,Z),L).

% premiere_etape(Tbox,Abi,Abr) :- tbox(Tbox), abi(Abi), abr(Abr).  nous avons modifié cette fonction donner dans le sujet pour ajouter les verifications
premiere_etape(Tbox, Abi, Abr):-  
	/* récuperation la TBox et la ABox */
    tbox(Tbox_0),
    abi(Abi_0),
    abr(Abr),
	/* On fait les vérifications avec ce qu'on a fait dans part1.pl */
	not(autoref(Tbox_0)), % verification de Tbox acyclique
	concept_all(Tbox_0, Abi_0, Abr), %
	traitement_Tbox(Tbox_0, Tbox),
	traitement_Abox(Abi_0, Abi).



deuxieme_etape(Abi,Abi1,Tbox) :-
    saisie_et_traitement_prop_a_demontrer(Abi,Abi1,Tbox).
  
saisie_et_traitement_prop_a_demontrer(Abi,Abi1,Tbox) :-
    nl, write("Entrez le numero du type de proposition que vous voulez demontrer :"), nl,
    write("1 = Une instance donnee appartient a un concept donne."), nl,
    write("2 = Deux concepts n`ont pas d'elements en commun (ils ont une intersection vide)."), nl,
    read(R), suite(R,Abi,Abi1,Tbox).
  
suite(1,Abi,Abi1,Tbox) :- acquisition_prop_type1(Abi,Abi1,Tbox),!.
suite(2,Abi,Abi1,Tbox) :- acquisition_prop_type2(Abi,Abi1,Tbox),!.
suite(_,Abi,Abi1,Tbox) :- nl, write("Cette reponse est incorrecte"),nl,saisie_et_traitement_prop_a_demontrer(Abi,Abi1,Tbox).

/*lire les Instances  depuis le Terminal*/
lecture_Instance(Instance) :- nl,
    write("Entrez le nom de l`instance :"), nl,
    read(I),
    (iname(I) , I = Instance; % si l'instance n'existe de pas on affiche un message et nous appelons recursivement la fonction
    write("Cette instance n`existe pas"), nl,
    lecture_Instance(Instance)). 

/*lire les Concepts depuis le Terminal*/
lecture_Concept(Concept) :- nl,
    write("Entrez le nom du concept :"), nl,
    read(C),
    ((not(autoref(C)),concept(C), Concept=C); % si le concept n'existe pas ou a une cycle on affiche un message et nous appelons recursivement la fonction
    write("Ce concept n`existe pas"), nl,
    lecture_Concept(Concept)).

acquisition_prop_type1(Abi,[(I,C1)| Abi],_) :- nl, 
    lecture_Instance(I),
    lecture_Concept(C),
    remplace_complexe(C,NC),
    nnf(not(NC),C1),
    write("La proposition ajoutee"), nl.

acquisition_prop_type2(Abi,[(I,C)| Abi],_) :- nl,
    lecture_Concept(C1),
    lecture_Concept(C2),
    genere(I),
    remplace_complexe(C1,NC1),
    remplace_complexe(C2,NC2),
    nnf(and(NC1,NC2),C),
    write("La proposition ajoutee"), nl.