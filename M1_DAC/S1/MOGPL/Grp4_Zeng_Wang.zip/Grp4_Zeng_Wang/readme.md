# Projet MOGPL 
## Optimisation equitable
- Fanxiang ZENG 28600693
- Zhe Wang  21116827

les codes sont des programmes python, pour les lancer utiliser en commande terminal
```bash 
python nom_fichier.py
```
ou bien 
```bash 
python3 nom_fichier.py
```

certain fichier pour voir les resultats sous different scenario vous aurez besoin de modifier les codes, comme indiqué dans les commentaires. 
- q41,q42 modifier `cout1 cout2` pour voir les resultats en scenario 1 et 2