package TestIntegration;

import java.beans.Transient;

public class TestGenHTML {
    ILivres livres = ComposantFactory.createLivresBouchon();
    livres.addLivre("fairy tail" , "un livre");
    
    @Test
    public void testGenHTML() throws Exception {
        Document doc = GenHTML.genHTML(livres.getLivre("fairy tail"));
        assertNotNull(doc);

    }
    @Test
    public void testGenHTMLfail() throws Exception {
        Document doc = GenHTML.genHTML(livres.getLivre("fairy tail"));
        assertNull(doc);
    }

}