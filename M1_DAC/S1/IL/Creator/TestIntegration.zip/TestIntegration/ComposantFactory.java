package TestIntegration;
public class ComposantFactory {
    public static ILivres createLivres() {
        return new ILivres();
    }

}