# Titre TV05 Interdiction Nominal

## Contexte
- u007 est un abonné non interdit
  
## Entrée
$$VOID$$

## Scenario
1. Choisir "Sanction"
2. Choisir "u007"
3. Selectionner "Interdire" et valide

## Resultat Attendu
- L'utilisateur u007 est désormais dit "Interdit" et n'a plus le droit a l'emprunt

## Moyen de Verification
- Validation Test TV07 Emprunt Alternative Interdit