# Titre Retour Nominal TV03

## Contexte
Juste a la suite de TV02
- l'Exemplaire Narnia_vol1_EX1 est dit "en prêt" par l'utilisateur u007

## Entrée
- Exemplaire: Narnia_vol1_EX1

## Scenario
1. Choisir "Retour"
2. Saisir idEx= Narnia_vol1_EX1
3. Saisir l'état TBE

## Resultat Attendu
- Le **Systeme** affiche de la fiche de l'abonné u007
- L'emprunt n'existe plus dans la liste
- L'exemplaire est dit "en rayon"


## Moyen De Vérification
- Verification visuel que l'emprunt n'existe plus.
- Lancement Test TV01.