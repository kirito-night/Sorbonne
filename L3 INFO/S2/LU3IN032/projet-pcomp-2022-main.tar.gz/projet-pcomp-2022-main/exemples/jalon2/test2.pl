p(A, X, f(g(Y))). 
?- p(Z, f(Z), f(U)).