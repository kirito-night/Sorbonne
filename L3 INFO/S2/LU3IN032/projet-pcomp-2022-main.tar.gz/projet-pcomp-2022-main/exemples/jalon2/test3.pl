r (X , Y , h ( Z ) ) .
q ( Z ) .
p ( Z , h ( Z , W) , f (W) ) .
?- p(f(X), h(Y, f(a)), Y).