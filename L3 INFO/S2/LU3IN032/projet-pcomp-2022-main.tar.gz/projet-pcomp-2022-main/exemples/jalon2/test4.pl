r (X , Y , h ( Z ) ) .
q ( Z , h ( Z , W) , f (W) ) .
p ( Z , h ( Z , W) , f (W) ) .
?- p ( f (X ) , h (Y , f ( a ) ) , Y ) .