class NotUnifiable(Exception):
    pass