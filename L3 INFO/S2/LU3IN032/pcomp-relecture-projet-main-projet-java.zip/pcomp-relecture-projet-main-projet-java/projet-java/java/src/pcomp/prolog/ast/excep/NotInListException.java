package pcomp.prolog.ast.excep;

public class NotInListException extends RuntimeException {
	public NotInListException(String msg) {
		super(msg);
		
	}
}
