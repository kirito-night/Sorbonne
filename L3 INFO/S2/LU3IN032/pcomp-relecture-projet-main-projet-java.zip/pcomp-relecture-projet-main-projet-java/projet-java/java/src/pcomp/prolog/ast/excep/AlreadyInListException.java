package pcomp.prolog.ast.excep;

public class AlreadyInListException extends RuntimeException {
	public AlreadyInListException(String msg) {
		super(msg);
		
	}
}
