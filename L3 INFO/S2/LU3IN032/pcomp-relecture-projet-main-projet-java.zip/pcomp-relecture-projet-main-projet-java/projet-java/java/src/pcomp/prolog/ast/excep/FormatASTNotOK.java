package pcomp.prolog.ast.excep;

public class FormatASTNotOK extends RuntimeException {
	
	public FormatASTNotOK(String msg) {
		super(msg);
	}
}
