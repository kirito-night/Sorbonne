p(X) :- q(X).
p(X) :- r(X).
q(a).
p(c).
r(b).

?- p(X).