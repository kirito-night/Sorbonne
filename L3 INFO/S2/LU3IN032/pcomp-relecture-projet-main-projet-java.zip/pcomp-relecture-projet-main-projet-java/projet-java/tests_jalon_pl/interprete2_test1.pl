q(Z).
?- p(f(X), h(Y, f(a)), Y), q(f(W)), r(Y, Y, h(Y)).