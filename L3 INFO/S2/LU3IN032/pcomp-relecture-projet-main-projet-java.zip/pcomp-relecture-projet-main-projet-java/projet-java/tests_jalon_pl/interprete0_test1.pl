p(Z, h(Z,W), f(W)).
?- p(f(X), g(Y), f(W)).