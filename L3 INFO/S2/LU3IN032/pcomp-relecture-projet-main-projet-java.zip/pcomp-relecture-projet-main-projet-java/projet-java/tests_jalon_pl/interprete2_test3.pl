insecte(fourmi).
felin(chat).
animal(humain).

?- animal(X), felin(Y).