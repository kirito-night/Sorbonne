insecte(fourmi).
felin(chat).
?- felin(X).