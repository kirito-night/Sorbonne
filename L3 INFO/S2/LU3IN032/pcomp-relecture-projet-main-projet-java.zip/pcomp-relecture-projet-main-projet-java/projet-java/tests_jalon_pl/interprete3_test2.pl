p(Z, h(Z, W), f(W)) :- r(X, XX), q(XX).
?- p(f(X), h(Y, a), Y), q(a).