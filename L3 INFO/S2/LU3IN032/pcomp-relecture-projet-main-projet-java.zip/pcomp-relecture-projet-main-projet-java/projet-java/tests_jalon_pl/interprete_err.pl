animal(chat) :- felin(chat).
felin(chat).
?- animal(chat).