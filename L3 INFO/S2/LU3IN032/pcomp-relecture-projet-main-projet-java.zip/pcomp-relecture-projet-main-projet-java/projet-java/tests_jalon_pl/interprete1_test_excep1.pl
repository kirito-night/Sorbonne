insecte(fourmi).
felin(chat).
animal(humain).
felin(lion).

?- animal(X).