q(X, r(U,X)).
?- q(r(Y,a), r(Z, r(b,Z))).