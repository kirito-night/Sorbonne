package pobj.motx.tme3.csp;

public interface IChoixVar {

    IVariable chooseVar(ICSP problem);
}
