package pobj.motx.tme2.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ GrillePlacesTest.class,
		DictionnaireTest.class, DictionnaireTest2.class, 
		GrillePotentielTest.class, GrillePotentielTest2.class,	GrillePotentielTest3.class })
public class TME2Tests {

}
