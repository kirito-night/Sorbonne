package pobj.motx.tme3.csp;

public interface IVariable {
    String[] getDomain();

    int getContraintesNumber();
}
