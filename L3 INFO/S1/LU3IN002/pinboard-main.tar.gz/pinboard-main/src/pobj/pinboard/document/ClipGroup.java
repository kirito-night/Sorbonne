package pobj.pinboard.document;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class ClipGroup implements Composite{
	private List<Clip> list; 
	
	
	public ClipGroup(List<Clip> list) {
		super();
		this.list = list;
	}

	public ClipGroup() {
		super();
		list = new ArrayList<>();
	}

	@Override
	public void draw(GraphicsContext ctx) {
		// TODO Auto-generated method stub
		for(Clip c : list) {
			c.draw(ctx);
		}
	}

	@Override
	public double getTop() {
		// TODO Auto-generated method stub
		double top = Double.POSITIVE_INFINITY;
		for(Clip c: list) {
			if(c.getTop()< top) {
				top = c.getTop();
			}
		}
		return top;
	}

	@Override
	public double getLeft() {
		// TODO Auto-generated method stub
		double left = Double.POSITIVE_INFINITY;
		for(Clip c: list) {
			if(c.getLeft() <  left) {
				left = c.getLeft();
			}
		}
		return left;
		
	}

	@Override
	public double getBottom() {
		// TODO Auto-generated method stub
		
		double bottom = Double.NEGATIVE_INFINITY;
		for(Clip c: list) {
			if(c.getBottom()>bottom) {
				bottom = c.getBottom();
			}
		}
		return bottom;
		
		 
	}

	@Override
	public double getRight() {
		// TODO Auto-generated method stub
		double right = Double.NEGATIVE_INFINITY;
		for(Clip c: list) {
			if(c.getRight() > right) {
				right = c.getRight();
			}
		}
		
		return right;
	}

	@Override
	public void setGeometry(double left, double top, double right, double bottom) {
		// TODO Auto-generated method stub
		for(Clip c : list) {
			
			double x =left -  c.getLeft();
			double y = top - c.getTop();
			c.move(x, y);
			
		}
	}

	@Override
	public void move(double x, double y) {
		// TODO Auto-generated method stub
		for(Clip c: list) {
			c.move(x, y);
		}
	}

	@Override
	public boolean isSelected(double x, double y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Color getColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setColor(Color c) {
		// TODO Auto-generated method stub
		for(Clip cl : list ) {
			cl.setColor(c);
		}
	}

	@Override
	public Clip copy() {
		// TODO Auto-generated method stub
		List<Clip> res = new ArrayList<>();
		for(Clip c : list) {
			res.add(c.copy());
		}
		
		
		return new ClipGroup(res);
	}

	@Override
	public List<Clip> getClips() {
		// TODO Auto-generated method stub
		return list;
	}

	@Override
	public void addClip(Clip toAdd) {
		// TODO Auto-generated method stub
		list.add(toAdd);
	}

	@Override
	public void removeClip(Clip toRemove) {
		// TODO Auto-generated method stub
		list.remove(toRemove);
	}

}
