package pobj.multiset;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import pobj.util.Chrono;

public class WorldCount {
	
	
	
	
	public static void wordcount(MultiSet<String> ms ,String nomFichier) throws IOException {
		String file = nomFichier;
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line; 
		while((line = br.readLine()) != null) {
			for(String word : line.split("\\P{L}+")) {
				if(word.equals("")) {
					continue;
				}
				ms.add(word);
				
			}
		}
		
		List<String> l = ms.elements();
		
		int i = 0;
		for(String s : l) {
			if(i ==10) {
				break;
			}
			System.out.println(s);
			i++;
		}
		
		br.close();
		
	}
	
	public static void main(String[] args) {
		MultiSet<String> ms1 = new HashMultiSet<>();
		try {
			Chrono c1 = new Chrono();
			WorldCount.wordcount(ms1,"data/WarAndPeace.txt");
			c1.stop();
		}catch(IOException o) {
			o.getMessage();
		}finally {
			System.out.println("fin du HashMultiset");
		}
		
		MultiSet<String> ms2 = new NaiveMultiSet<>();
		try {
			Chrono c2 = new Chrono();
			System.out.println("début chrono naives");
			WorldCount.wordcount(ms2,"data/test.txt");
			c2.stop();
		}catch(IOException o) {
			o.getMessage();
		}finally {
			System.out.println("fin du NaiveMultiset");
		}
		
		
	}
	
	
	
}
