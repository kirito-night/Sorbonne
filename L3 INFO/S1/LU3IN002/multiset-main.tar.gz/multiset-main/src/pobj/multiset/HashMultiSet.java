package pobj.multiset;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class HashMultiSet<T> extends AbstractCollection<T> implements MultiSet<T>{
	private int size = 0;
	private HashMap<T, Integer> hmap; 
	
	public HashMultiSet(){
		this.hmap = new HashMap<>();
		
	}
	
	
	
	@Override
	public boolean add(T e, int count) {
		// TODO Auto-generated method stub
		if(hmap.containsKey(e)) {
			Integer i = hmap.get(e);
			hmap.put(e, i+count);
			
		}else {
			if(count == 0) {
				return false;
			}
			hmap.put(e, count);
			
		}
		
		this.size += count;
		
		return true;
	}
	@Override
	public boolean add(T e) {
		// TODO Auto-generated method stub
		return this.add(e, 1);
		
	}
	
	public  HashMultiSet (Collection<T> coll) {
		// TODO Auto-generated constructor stub
		this.hmap = new HashMap<>();
		for(T e: coll) {
			this.add(e);
		}
		
	}
	
	@Override
	public boolean remove(Object e) {
		// TODO Auto-generated method stub
		return this.remove(e, 1);
		
	}
	@Override
	public boolean remove(Object e, int count) {
		// TODO Auto-generated method stub
		if(count == 0) {
			return false;
		}
		
		if(hmap.containsKey(e)) {
			Integer nV =  hmap.get(e) - count;
			if(nV < 0) {
				size -= hmap.get(e);
				hmap.remove(e);
				
				
			}else {
				hmap.put((T)e,nV);
				size -= count;
			}
			return true;
		}
		
		
		return false;
	}
	/**
	 * indique le nb d'occurence de l'objet e dans la collection 
	 */
	
	@Override
	public int count(T o) {
		// TODO Auto-generated method stub
		if(this.hmap.containsKey(o)) {
			return  hmap.get(o);
		}
		
		return 0;
	}
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		size = 0;
		this.hmap.clear();
		
	}
	@Override
	public int size() {
		return size;
	}
	
	public Iterator<T> iterator(){
		return new HashMultiSetIterator();
	}
	
	private class HashMultiSetIterator implements Iterator<T>{
		private Iterator <Map.Entry<T, Integer>> it = hmap.entrySet().iterator();
		private Map.Entry<T, Integer> current;
		private int nbRest; 
		
		

		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return (nbRest>0 || it.hasNext() );
			
		}

		@Override
		public T next() {
			// TODO Auto-generated method stub
			if(nbRest ==0) {
				current = it.next();
				
				nbRest = current.getValue();
			}
			nbRest-=1;
			
			return current.getKey();
		}
		
		
		public void remove() throws UnsupportedOperationException{
			/*while(it.hasNext()) {
				current = it.next();
			}
			hmap.remove(current.getKey());*/
			it.remove();
		}
		
		
	}

	@Override
	public List<T> elements() {
		// TODO Auto-generated method stub
		List<T> res;
	
		
		res= hmap.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).map(Map.Entry::getKey).collect(Collectors.toList());
		
		return res;
	}
	
	
	
	
	
}
