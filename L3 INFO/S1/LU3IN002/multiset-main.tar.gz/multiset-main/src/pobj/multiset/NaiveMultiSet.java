package pobj.multiset;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class NaiveMultiSet<T> extends AbstractCollection<T> implements MultiSet<T> {
	private ArrayList<T> array;
	private int size = 0;
	
	public NaiveMultiSet() {
		array =new ArrayList<>();
	}

	@Override
	public boolean add(T e, int count) {
		// TODO Auto-generated method stub
		if(count == 0) {
			return false;
		}
		for(int i = 0; i< count ; i++ ) {
			array.add(e);
			size++;
		}
		return true;
		
	}

	@Override
	public boolean add(T e) {
		// TODO Auto-generated method stub
		return this.add(e, 1);
		
	}
	
	@Override
	public boolean remove(Object e, int count) {
		// TODO Auto-generated method stub
		if(count ==0 || !(array.contains(e))) {
			return false;
		}
		for(int i  =0 ; i < count ; i++) {
			if(array.contains(e)) {
				array.remove(e);
				size--;
			}else {
				break;
			}
		}
		
		return true;
	}
	
	@Override 
	public boolean remove(Object e) {
		return this.remove(e, 1);
	}

	@Override
	public int count(T o) {
		int res=0;
		for(T t: array) {
			if(t.equals(o)) {
				res++;
			}
			
		}
		return res;
	}

	@Override
	public List<T> elements() {
		List<T> listtrie = new ArrayList<>();
        for (T o : array) {
            if (!listtrie.contains(o)) {
                listtrie.add(o);
            }
			
		}
        
        Collections.sort(listtrie, new Comparator<T>() {
            @Override
            public int compare(T o1, T o2) {
                return count(o2) - count(o1);
            }
        });	
        
        return listtrie;
	}

	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return new NaiveMultiSetIterator();
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}
	
	public void clear() {
		array.removeAll(array);
	}
	
	
	private class NaiveMultiSetIterator implements Iterator<T>{
		private int index = 0;
		
		public boolean hasNext() {
			return index < size;
		}
		
		public T next() {
			return array.get(++index);
		}
	}
	
	
}
